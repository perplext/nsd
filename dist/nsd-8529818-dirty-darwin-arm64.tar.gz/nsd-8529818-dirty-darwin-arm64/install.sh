#!/bin/bash
set -e

BINARY_NAME="nsd"
INSTALL_DIR="/usr/local/bin"
MAN_DIR="/usr/local/share/man/man1"

echo "Installing NSD..."

# Install binary
sudo install -m 755 "$BINARY_NAME" "$INSTALL_DIR/"

# Install man page
if [ -f "man/${BINARY_NAME}.1" ]; then
    sudo mkdir -p "$MAN_DIR"
    sudo install -m 644 "man/${BINARY_NAME}.1" "$MAN_DIR/"
    # Update man database if available
    if command -v mandb >/dev/null 2>&1; then
        sudo mandb >/dev/null 2>&1 || true
    elif command -v makewhatis >/dev/null 2>&1; then
        sudo makewhatis >/dev/null 2>&1 || true
    fi
fi

echo "NSD installed successfully!"
echo "Run 'sudo nsd -i <interface>' to start monitoring"
